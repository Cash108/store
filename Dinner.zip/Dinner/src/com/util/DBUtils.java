package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
	//获取数据库连接
	public static Connection getConnection() {
		Connection conn=null;
		try{
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/test?user=root&password=123456&useUnicode=true&characterEncoding=utf8&useSSL=true";
			conn = DriverManager.getConnection(url);
		} catch(ClassNotFoundException e){
			System.out.println(e.getMessage());
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	//关闭连接
    public static void commit(Connection conn){
		try{
			if(conn!=null){
				conn.close();
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
}
