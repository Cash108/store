package com.util;

import java.util.UUID;
/**
 *获得唯一id
 */
public class GUIDGet {
	private static UUID uuid;
	public static String getGUID(){
		uuid=UUID.randomUUID();
		String guid=uuid.toString();
		return guid;
	}
}