package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.OrderInfoBean;
import com.util.DBUtils;
import com.util.GUIDGet;

public class OrderInfoDAO {
	public OrderInfoBean queryOrder(String orderId) throws Exception{
		OrderInfoBean orderInfoBean=new OrderInfoBean();
		String sql="select * from orderinfo where order_id='"+orderId+"'";
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		if((rs=stmt.executeQuery(sql))!=null){
			System.out.println("显示订单：true");
		}else{
			System.out.println("显示订单：false");
		}
		if(rs.next()){
			orderInfoBean.setOrderId(orderId);
			orderInfoBean.setUserId(rs.getString(2));
			orderInfoBean.setOrderTime(rs.getString(3));
			orderInfoBean.setEatingTime(rs.getString(4));
			orderInfoBean.setRestaurant(rs.getString(5));
			orderInfoBean.setMinnumber(rs.getInt(6));
			orderInfoBean.setMaxnumber(rs.getInt(7));
			orderInfoBean.setAddress(rs.getString(8));
			orderInfoBean.setStyle(rs.getString(9));
			orderInfoBean.setCity(rs.getString(10));
			orderInfoBean.setTelephone(rs.getString(11));
			orderInfoBean.setNumber(rs.getInt(12));
			orderInfoBean.setSituation(rs.getString(13));
		}
		//关闭连接
		rs.close();
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return orderInfoBean;
	}
	
	public List<OrderInfoBean> queryOrderList(int page) throws Exception{
		List orderList=new ArrayList<OrderInfoBean>();
		OrderInfoBean orderInfoBean=new OrderInfoBean();
		String sql="select * from orderinfo order by order_time desc limit 6 offset "+(page-1)*6;
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		if((rs=stmt.executeQuery(sql))!=null){
			System.out.println("显示订单：true");
		}else{
			System.out.println("显示订单：false");
		}
		while(rs.next()){
			orderInfoBean.setOrderId(rs.getString(1));
			orderInfoBean.setUserId(rs.getString(2));
			orderInfoBean.setOrderTime(rs.getString(3));
			orderInfoBean.setEatingTime(rs.getString(4));
			orderInfoBean.setRestaurant(rs.getString(5));
			orderInfoBean.setMinnumber(rs.getInt(6));
			orderInfoBean.setMaxnumber(rs.getInt(7));
			orderInfoBean.setAddress(rs.getString(8));
			orderInfoBean.setStyle(rs.getString(9));
			orderInfoBean.setCity(rs.getString(10));
			orderInfoBean.setTelephone(rs.getString(11));
			orderInfoBean.setNumber(rs.getInt(12));
			orderInfoBean.setSituation(rs.getString(13));
			orderList.add(orderInfoBean);
		}
		//关闭连接
		rs.close();
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return orderList;
	}
	
	public boolean addOrder(OrderInfoBean orderInfoBean) throws Exception{
		boolean flag=false;
		orderInfoBean.setOrderId(GUIDGet.getGUID());
		orderInfoBean.setNumber(1);
		orderInfoBean.setSituation("wait");
		String sql="INSERT INTO orderinfo VALUES ('"+orderInfoBean.getOrderId()+
				"','"+orderInfoBean.getUserId()+"','"+orderInfoBean.getOrderTime()+
				"','"+orderInfoBean.getEatingTime()+"','"+orderInfoBean.getRestaurant()+
				"',"+orderInfoBean.getMinnumber()+","+orderInfoBean.getMaxnumber()+
				",'"+orderInfoBean.getAddress()+"','"+orderInfoBean.getStyle()+
				"','"+orderInfoBean.getCity()+"','"+orderInfoBean.getTelephone()+
				"',"+orderInfoBean.getNumber()+",'"+orderInfoBean.getSituation()+"')";
		Statement stmt=null;
		Connection conn = DBUtils.getConnection();
		stmt=conn.createStatement();
		if(stmt.executeUpdate(sql)==1){
			flag=true;
		}else{
			flag=false;
		}
		System.out.println("建立订单DAO："+flag);
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);
		return flag;
	}
}
