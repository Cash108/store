package com.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.bean.UserInfoBean;
import com.util.DBUtils;

public class UserInfoDAO {
	 
	public boolean updateName(String userid,String nickname)  throws Exception{
		boolean flag = false;
		String sql = "UPDATE userinfo SET nickname = '" + nickname + "'WHERE user_id = '" + userid + "'";
		Statement stmt=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		
		if(stmt.executeUpdate(sql)==1){
			flag=true;	
		}else{
			flag=false;
		}
		System.out.println("nickname:"+flag);
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return flag;
	}
	
	public boolean updateGender(String userid,String gender)  throws Exception{
		boolean flag = false;
		String sql = "UPDATE userinfo SET gender = '" + gender + "'WHERE user_id = '" + userid + "'";
		Statement stmt=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		
		if(stmt.executeUpdate(sql)==1){
			flag=true;	
		}else{
			flag=false;
		}
		System.out.println("gender:"+flag);
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return flag;
	}
	
	public boolean updateArea(String userid,String area)  throws Exception{
		boolean flag = false;
		String sql = "UPDATE userinfo SET area = '" + area + "'WHERE user_id = '" + userid + "'";
		Statement stmt=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();

		if(stmt.executeUpdate(sql)==1){
			flag=true;	
		}else{
			flag=false;
		}
		System.out.println("area:"+flag);
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return flag;
	}

	public boolean updateSchool(String userid,String school)  throws Exception{
		boolean flag = false;
		String sql = "UPDATE userinfo SET school = '" + school + "'WHERE user_id = '" + userid + "'";
		Statement stmt=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();

		if(stmt.executeUpdate(sql)==1){
			flag=true;	
		}else{
			flag=false;
		}
		System.out.println("school:"+flag);
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return flag;
	}
	
	public UserInfoBean getUserInfo(String userid) throws Exception{
		UserInfoBean userInfoBean=new UserInfoBean();
		String sql = "SELECT * FROM userinfo WHERE user_id = '" + userid + "'";
		Statement stmt=null;
		ResultSet rs= null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		
		if(rs.next()){
			userInfoBean.setId(userid);
			userInfoBean.setNickName(rs.getString(2));
			userInfoBean.setGender(rs.getString(3));
			userInfoBean.setArea(rs.getString(4));
			userInfoBean.setSchool(rs.getString(5));
		}
		//关闭连接
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		System.out.println("显示个人信息："+userInfoBean.getGender());
		return userInfoBean;
	}
}

