package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.util.DBUtils;
import com.util.GUIDGet;

public class UserDAO {
	//判断用户登录，查询数据库进行判断
	public boolean queryUser(String username,String pwd) throws Exception{
		//标记 是否登录成功
		boolean flag=false;
		String sql="select * from user where telephone='"+username+"' and password='"+pwd+"'";
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		//如果存在记录，则表示登录成功
		if(rs.next()){
			flag=true;	
		
		}else{
			flag=false;
		}
		//关闭连接
		rs.close();
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		System.out.println("登录："+flag);
		return flag;
	}

	public String getUserID(String username) throws Exception{
		String sql="select user_id from user where telephone='"+username+"'";
		Statement stmt=null;
		ResultSet rs=null; 
		Connection conn = DBUtils.getConnection();	
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		String userid = null;
		if(rs.next()){
			userid = rs.getString(1);
		}
		//关闭连接
		rs.close();
		stmt.close();
		DBUtils.commit(conn);//关闭连接
		return userid;
	}
	
	//注册
	@SuppressWarnings("resource")
	public boolean addUser(String username,String pwd) throws Exception{
		boolean flag=false;
		String id=GUIDGet.getGUID();
		String sql1="INSERT INTO user(user_id,telephone,password) VALUES ('"+id+"','"+username+"','"+pwd+"')";
		String sql2="INSERT INTO userInfo(user_id) VALUES ('"+id+"')";
		PreparedStatement pre=null;
		Connection conn = DBUtils.getConnection();		
		
		//try...catch...finally部分
		try{
			//设置事务提交方式为非自动提交
			conn.setAutoCommit(false);
			//执行sql语句1
			pre=conn.prepareStatement(sql1);
			pre.executeUpdate();
			//执行sql语句2
			pre=conn.prepareStatement(sql2);
			pre.executeUpdate();
			//若操作无异常，则提交
			conn.commit();
			//将事务提交方式设置回自动提交
			conn.setAutoCommit(true);
			flag=true;
		}catch(SQLException e){
			//若出错进入catch块
			e.printStackTrace();
			//try...catch部分
			try{
				//若执行上面的try部分出现异常，则先判断数据库是否正确连接，正确连接则进入if语句
				if(conn!=null){
					conn.rollback();//若数据库正确正确连接，则说明sql执行异常，之前的操作回滚(rollback)
					conn.setAutoCommit(true);//将事务提交方式设置回自动提交
				}
			}catch(SQLException e1){
				e1.printStackTrace();
			}
		}finally{
			//无论操作是否执行，最后都要关闭PreparedStatement和数据库连接
			try{
				//关闭PreparedStatement
				pre.close();
				//调用工具包的DBUtil类的closeConnection方法关闭数据库连接
				DBUtils.commit(conn);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		System.out.println("注册:"+flag);
		return flag;
	}
}
