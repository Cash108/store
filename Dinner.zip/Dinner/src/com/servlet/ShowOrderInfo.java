package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.bean.OrderInfoBean;
import com.dao.OrderInfoDAO;

/**
 * Servlet implementation class ShowOrderInfo
 */
@WebServlet("/ShowOrderInfo")
public class ShowOrderInfo extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.转码
		request.setCharacterEncoding("utf-8");
		//2.接收数据
		String orderId=request.getParameter("orderId");
		OrderInfoBean orderInfoBean=new OrderInfoBean();
		System.out.println("显示订单："+orderId);
		//3.调用DAO层
		OrderInfoDAO orderInfoDAO=new OrderInfoDAO();
		try{
			orderInfoBean=orderInfoDAO.queryOrder(orderId);
			System.out.println("显示订单："+orderInfoBean.getStyle());
			//把数据封装成JSONObject
			JSONObject result=new JSONObject();
			result.put("orderId", orderId);
			result.put("userId", orderInfoBean.getUserId());
			result.put("orderTime", orderInfoBean.getOrderTime());
			result.put("eatingTime", orderInfoBean.getEatingTime());
			result.put("restaurant", orderInfoBean.getRestaurant());
			result.put("minnumber", orderInfoBean.getMinnumber());			
			result.put("maxnumber", orderInfoBean.getMaxnumber());
			result.put("address", orderInfoBean.getAddress());
			result.put("city", orderInfoBean.getCity());
			result.put("style", orderInfoBean.getStyle());
			result.put("telephone", orderInfoBean.getTelephone());
			result.put("number", orderInfoBean.getNumber());
			result.put("situation", orderInfoBean.getSituation());
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
