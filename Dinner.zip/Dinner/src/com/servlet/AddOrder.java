package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.bean.OrderInfoBean;
import com.dao.OrderInfoDAO;

/**
 * Servlet implementation class AddOrder
 */
@WebServlet("/AddOrder")
public class AddOrder extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flag="false";
		request.setCharacterEncoding("utf-8");
		OrderInfoBean orderInfoBean=new OrderInfoBean();
		orderInfoBean.setUserId(request.getParameter("userId"));
		orderInfoBean.setOrderTime(request.getParameter("orderTime"));
		orderInfoBean.setEatingTime(request.getParameter("eatingTime"));
		orderInfoBean.setRestaurant(request.getParameter("restanurant"));
		orderInfoBean.setMinnumber(Integer.parseInt(request.getParameter("minNumber")));
		orderInfoBean.setMaxnumber(Integer.parseInt(request.getParameter("maxNumber")));
		orderInfoBean.setAddress(request.getParameter("address"));
		orderInfoBean.setStyle(request.getParameter("style"));
		orderInfoBean.setCity(request.getParameter("city"));
		orderInfoBean.setTelephone(request.getParameter("telephone"));
		System.out.println("建立订单："+orderInfoBean.getUserId());
		System.out.println("建立订单："+orderInfoBean.getStyle());
		OrderInfoDAO orderInfoDAO=new OrderInfoDAO();
		try {
			boolean isflag=orderInfoDAO.addOrder(orderInfoBean);
			if(isflag==true){
				flag="true";
			}else{
				flag="false";
			}
			System.out.println("建立订单："+flag);
			//把登录状态数据封装成JSONObject
			JSONObject result=new JSONObject();
			result.put("flag", flag);
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		} catch (Exception e){
			e.printStackTrace();
		}
		
	}

}
