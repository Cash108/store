package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.bean.UserInfoBean;
import com.dao.UserInfoDAO;

/**
 * Servlet implementation class ShowUserInfo
 */
@WebServlet("/ShowUserInfo")
public class ShowUserInfo extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.转码
		request.setCharacterEncoding("utf-8");
		//2.接收数据
		String userid=request.getParameter("user_id");
		System.out.println("显示个人信息："+userid);
		UserInfoBean userInfoBean=new UserInfoBean();
		//3.调用DAO层
		UserInfoDAO infodao=new UserInfoDAO();
		try{
			userInfoBean = infodao.getUserInfo(userid);
			//把数据封装成JSONObject
			System.out.println("显示个人信息："+userInfoBean.getNickName());
			JSONObject result=new JSONObject();
			result.put("nickname", userInfoBean.getNickName());
			result.put("gender",userInfoBean.getGender());
			result.put("area", userInfoBean.getArea());
			result.put("school", userInfoBean.getSchool());
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
