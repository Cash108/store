package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.bean.UserInfoBean;
import com.dao.UserDAO;
import com.dao.UserInfoDAO;

/**
 * Servlet implementation class UpdateUserInfo
 */
@WebServlet("/UpdateUserInfo")
public class UpdateUserInfo extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.转码
		request.setCharacterEncoding("utf-8");
		//2.接收数据
		String userid=request.getParameter("user_id");
		String nickname = request.getParameter("nickname");
		String gender = request.getParameter("gender");
		String area = request.getParameter("area");
		String school = request.getParameter("school");
		System.out.println("修改个人信息："+userid);
		System.out.println("修改个人信息："+nickname);
		System.out.println("修改个人信息："+gender);
		System.out.println("修改个人信息："+area);
		System.out.println("修改个人信息："+school);
		//3.调用DAO层
		UserInfoDAO infodao=new UserInfoDAO();
		String flag="false";
		boolean isflag = false;
		try{
			//加一个非空判断，即可分别进入不同项 的update
			if(nickname!=null&&!nickname.isEmpty()){
				isflag = infodao.updateName(userid, nickname);
			} 
			else if(gender!=null&&!gender.isEmpty()){
			    isflag = infodao.updateGender(userid, gender);
			}
			else if(area!=null&&!area.isEmpty()){
			    isflag = infodao.updateArea(userid, area);
			}
			else if(school!=null&&!school.isEmpty()){
			    isflag = infodao.updateSchool(userid, school);
			}		
			if(isflag==true){
				flag="true";
			}else{
				flag="false";
			}
			System.out.println("修改个人信息："+flag);
			//把数据封装成JSONObject
			JSONObject result=new JSONObject();
			result.put("flag", flag);
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
