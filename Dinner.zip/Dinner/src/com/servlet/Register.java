package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.dao.UserDAO;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.转码
		request.setCharacterEncoding("utf-8");
		//2.接收数据
		String username=request.getParameter("username");
		System.out.println("注册："+username);
		String pwd=request.getParameter("pwd");
		//3.进行登录判断，调用DAO层
		UserDAO dao=new UserDAO();
		String flag="false";
		String userid = null;
		try {
			boolean isflag = dao.addUser(username,pwd);
			if(isflag==true){
				flag="true";
				userid=dao.getUserID(username);
			}else{
				flag="false";
			}
			System.out.println("注册："+userid);
			//把登录状态数据封装成JSONObject
			JSONObject result=new JSONObject();
			result.put("flag", flag);
			result.put("user_id", userid);
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
