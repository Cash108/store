package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.bean.OrderInfoBean;
import com.dao.OrderInfoDAO;

/**
 * Servlet implementation class showOrderList
 */
@WebServlet("/showOrderList")
public class showOrderList extends HttpServlet {
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.转码
		request.setCharacterEncoding("utf-8");
		//2.接收数据
		int page=Integer.parseInt(request.getParameter("page"));
		System.out.println("显示订单列表："+page);
		OrderInfoBean orderInfoBean=new OrderInfoBean();
		List orderList=new ArrayList<OrderInfoBean>();
		//3.调用DAO层
		OrderInfoDAO orderInfoDAO=new OrderInfoDAO();
		try{
			orderList=orderInfoDAO.queryOrderList(page);
			//把数据封装成JSONObject
			JSONObject result=new JSONObject();
			int listNum=orderList.size();
			System.out.println("显示订单列表："+listNum);
			result.put("listNum", listNum);
			for(int i=1;i<=listNum;i++){
				orderInfoBean=(OrderInfoBean)orderList.get(i-1);
				result.put("orderId"+i, orderInfoBean.getOrderId());
				result.put("userId"+i, orderInfoBean.getUserId());
				result.put("orderTime"+i, orderInfoBean.getOrderTime());
				result.put("eatingTime"+i, orderInfoBean.getEatingTime());
				result.put("restaurant"+i, orderInfoBean.getRestaurant());
				result.put("minnumber"+i, orderInfoBean.getMinnumber());			
				result.put("maxnumber"+i, orderInfoBean.getMaxnumber());
				result.put("address"+i, orderInfoBean.getAddress());
				result.put("city"+i, orderInfoBean.getCity());
				result.put("style"+i, orderInfoBean.getStyle());
				result.put("telephone"+i, orderInfoBean.getTelephone());
				result.put("number"+i, orderInfoBean.getNumber());
				result.put("situation"+i, orderInfoBean.getSituation());
			}
			//设置服务器响应的编码，防止中文乱码
			response.setContentType("text/html; charset=utf-8");
			//服务器返回结果给客户端
			response.getWriter().println(result.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
