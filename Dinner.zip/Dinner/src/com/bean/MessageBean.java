package com.bean;

public class MessageBean {
	private String Id1;
	private String Id2;
	private String time;
	private String content;
	private int read;
	public String getId1() {
		return Id1;
	}
	public void setId1(String id1) {
		Id1 = id1;
	}
	public String getId2() {
		return Id2;
	}
	public void setId2(String id2) {
		Id2 = id2;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getRead() {
		return read;
	}
	public void setRead(int read) {
		this.read = read;
	}
}
